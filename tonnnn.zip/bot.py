import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from handlers import (
    start_command,
    help_command,
    balance_command,
    deposit_command,
    withdraw_command,
    admin_add_balance,
    admin_help_command,
    button_callback,
    unknown_command,
    text_message_handler,
    process_dice_throw,
    dice_timeout_callback,
    risk_command,
    language_command
)
from config import ADMIN_ID

logger = logging.getLogger(__name__)

def setup_bot():
    """Initialize and start the Telegram bot"""
    # Get the token from environment variable
    token = os.getenv("TELEGRAM_TOKEN")
    if not token:
        logger.error("No TELEGRAM_TOKEN found in environment variables!")
        return

    # Create the Application with job queue
    application = Application.builder().token(token).build()

    # Register command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("balance", balance_command))
    application.add_handler(CommandHandler("deposit", deposit_command))
    application.add_handler(CommandHandler("withdraw", withdraw_command))
    application.add_handler(CommandHandler("risk", risk_command))
    application.add_handler(CommandHandler("language", language_command))
    
    # Admin command handlers
    application.add_handler(CommandHandler("admin_add", admin_add_balance))
    application.add_handler(CommandHandler("admin_help", admin_help_command))
    
    # Handle button callbacks
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Handle unknown commands
    application.add_handler(MessageHandler(filters.COMMAND, unknown_command))
    
    # Handle text messages (for bet patterns with #شرط)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message_handler))
    
    # Handle dice throws
    application.add_handler(MessageHandler(filters.Dice.ALL, process_dice_throw))
    
    # Start the Bot
    logger.info("Starting bot...")
    # Use simplest form of run_polling without specifying allowed_updates
    application.run_polling()

    return application
