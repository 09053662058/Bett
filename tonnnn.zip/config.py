import os

# Bot configuration
MIN_BET = 0.1  # Minimum bet amount in TON
MAX_BET = 10.0  # Maximum bet amount in TON
WITHDRAWAL_FEE_PERCENT = 5  # Fee percent for withdrawals (5%)
ROLL_TIMEOUT = 20  # Timeout for dice roll in seconds
DEPOSIT_CHECK_TIMEOUT = 60  # Seconds to wait for checking deposit transaction
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))  # Telegram user ID of the admin
DATA_DIR = "data"
USER_DATA_FILE = f"{DATA_DIR}/users.json"
TON_WALLET_ADDRESS = "UQD4pyJuRZxozkjl1PFcTE4uBqIRyVdApRD-kM2lzcfD1vts"  # TON wallet address for deposits
RISK_ANALYSIS_ENABLED = False  # Disable risk analysis feature

# Available languages
LANGUAGES = ["fa", "en", "ru"]  # Persian, English, Russian
DEFAULT_LANGUAGE = "fa"  # Default language

# Check and create data directory if doesn't exist
import os
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

# Text messages for all supported languages
MESSAGES = {

    "welcome": """
🎲 به ربات شرط‌بندی TON خوش آمدید! 🎲

در این ربات شما می‌توانید روی فرد یا زوج بودن مجموع سه تاس شرط ببندید.

برای شروع، از دستورات زیر استفاده کنید:
/balance - مشاهده موجودی
/deposit <مبلغ> - افزایش موجودی
/withdraw <آدرس> <مبلغ> - درخواست برداشت از موجودی
/risk - مشاهده آنالیز ریسک و تاریخچه شرط‌بندی
/language - تغییر زبان ربات
/help - راهنمای کامل ربات

یا با استفاده از فرمت زیر شرط‌بندی کنید:
#شرط فرد 0.5
#شرط زوج 0.5

حداکثر مبلغ شرط: 10 TON
کارمزد برداشت: 5% مبلغ درخواستی
""",
    
    "help": """
🔹 راهنمای ربات شرط‌بندی TON 🔹

⚪️ دستورات اصلی:
/balance - مشاهده موجودی فعلی حساب
/deposit <مبلغ> - واریز به کیف پول ربات
/withdraw <آدرس> <مبلغ> - درخواست برداشت از موجودی به کیف پول خود
/risk - مشاهده آنالیز ریسک و تاریخچه شرط‌بندی
/language - تغییر زبان ربات

⚪️ روش شرط‌بندی:
با ارسال پیام به فرمت زیر:
#شرط فرد 0.5
#شرط زوج 0.5

⚪️ قوانین شرط‌بندی:
- شما می‌توانید روی فرد یا زوج بودن مجموع سه تاس شرط ببندید
- پس از ارسال پیام شرط، باید 3 تاس بیندازید
- برنده شرط 2 برابر مبلغ شرط خود را دریافت می‌کند
- باخت در شرط به معنی از دست دادن مبلغ شرط است

⚪️ نکات مهم:
- حداقل مبلغ شرط 0.1 TON است
- حداکثر مبلغ شرط 10 TON است
- همواره از موجودی کافی اطمینان حاصل کنید
- پرداخت‌ها و برداشت‌ها در شبکه TON انجام می‌شود
- کارمزد برداشت 5% مبلغ درخواستی است
- در هنگام برداشت، فقط مبلغ درخواستی به علاوه کارمزد از حساب شما کسر می‌شود
- آدرس ولت TON برای شارژ حساب: UQD4pyJuRZxozkjl1PFcTE4uBqIRyVdApRD-kM2lzcfD1vts
""",
    
    "balance": "💰 موجودی فعلی شما: {balance} TON",
    "insufficient_balance": "❌ موجودی کافی نیست. موجودی فعلی شما {balance} TON است.",
    "invalid_bet_amount": "❌ مبلغ شرط نامعتبر است. مبلغ باید حداقل {min_bet} TON باشد.",
    "bet_start": "🎲 شرط شما با مبلغ {amount} TON ثبت شد. روی چه چیزی شرط می‌بندید؟",
    "bet_odd": "فرد",
    "bet_even": "زوج",
    "bet_timeout": "⏰ زمان شرط‌بندی به پایان رسید!",
    "bet_dice_rolling": "🎲 در حال پرتاب تاس...",
    "roll_dice_instruction": "🎲 لطفاً با استفاده از دکمه تاس در تلگرام، 3 تاس بیندازید.",
    "more_dice_needed": "🎲 تاس شماره {current} از 3 ثبت شد. شما باید {remaining} تاس دیگر بیندازید. لطفاً از دکمه تاس استفاده کنید.",
    "dice_timeout_refund": "⏰ زمان انداختن تاس به پایان رسید! مبلغ شرط به شما بازگردانده شد.",
    "dice_timeout_no_refund": "⏰ زمان انداختن تاس به پایان رسید! شما هیچ تاسی نینداختید، مبلغ شرط از دست رفت.",
    "bet_result": "🎲 نتیجه تاس‌ها: {dice1}, {dice2}, {dice3}\nمجموع: {total} ({result})",
    "bet_win": "🎉 تبریک! شما برنده شدید! {amount} TON به موجودی شما اضافه شد.",
    "bet_lose": "😔 متأسفانه باختید! {amount} TON از موجودی شما کسر شد.",
    "deposit_info": """
💳 برای شارژ حساب خود، دقیقاً {amount} TON به آدرس زیر ارسال کنید:

{address}

سیستم به صورت خودکار تراکنش شما را بررسی و موجودی حساب شما را به‌روزرسانی خواهد کرد.

لطفاً حتماً مبلغ دقیق را ارسال کنید تا سیستم بتواند تراکنش شما را شناسایی کند.
""",
    "withdraw_success": "✅ برداشت {amount} TON به آدرس {address} با موفقیت انجام شد.",
    "withdraw_error": "❌ خطا در برداشت. لطفاً مجدداً تلاش کنید.",
    "admin_add_success": "✅ {amount} TON به موجودی کاربر {user_id} اضافه شد.",
    "admin_add_error": "❌ خطا در افزودن موجودی. دستور صحیح: /admin_add <user_id> <amount>",
    "not_admin": "❌ این دستور فقط برای ادمین قابل استفاده است.",
    "unknown_command": "❓ دستور ناشناخته. برای مشاهده راهنما از /help استفاده کنید.",
    "admin_help": """
⚠️ دستورات مدیریتی (فقط ادمین):

1️⃣ افزودن موجودی با دستور:
/admin_add <user_id> <amount>

2️⃣ افزودن موجودی با پاسخ به پیام کاربر:
کافیست به پیام کاربر پاسخ دهید و متن +amount را بنویسید. مثال: +5

3️⃣ کم کردن موجودی با پاسخ به پیام کاربر:
کافیست به پیام کاربر پاسخ دهید و متن -amount را بنویسید. مثال: -6

4️⃣ درخواست‌های برداشت:
درخواست‌های برداشت کاربران به شما اعلام می‌شود و باید به صورت دستی انجام دهید.
"""
}

# English messages
MESSAGES_EN = {
    "welcome": """
🎲 Welcome to the TON Betting Bot! 🎲

In this bot, you can bet on whether the sum of three dice will be odd or even.

To get started, use the following commands:
/balance - Check your balance
/deposit <amount> - Add funds to your account
/withdraw <address> <amount> - Request withdrawal
/risk - View risk analysis and betting history
/help - Full bot guide
/language - Change language

Or place a bet using the following format:
#bet odd 0.5
#bet even 0.5

Maximum bet: 10 TON
Withdrawal fee: 5% of the requested amount
""",
    
    "help": """
🔹 TON Betting Bot Guide 🔹

⚪️ Main Commands:
/balance - Check your current balance
/deposit <amount> - Deposit to the bot wallet
/withdraw <address> <amount> - Request withdrawal to your wallet
/language - Change language

⚪️ Betting Method:
Send a message in this format:
#bet odd 0.5
#bet even 0.5

⚪️ Betting Rules:
- You can bet on whether the sum of three dice will be odd or even
- After sending your bet, you need to roll 3 dice
- The winner receives 2 times their bet amount
- Losing a bet means losing your bet amount

⚪️ Important Notes:
- Minimum bet amount is 0.1 TON
- Maximum bet amount is 10 TON
- Always ensure you have sufficient balance
- Payments and withdrawals are processed on the TON network
- Withdrawal fee is 5% of the requested amount
- When withdrawing, only the requested amount plus fee is deducted from your account
- TON wallet address for deposits: UQD4pyJuRZxozkjl1PFcTE4uBqIRyVdApRD-kM2lzcfD1vts
""",
    
    "balance": "💰 Your current balance: {balance} TON",
    "insufficient_balance": "❌ Insufficient balance. Your current balance is {balance} TON.",
    "invalid_bet_amount": "❌ Invalid bet amount. Amount must be at least {min_bet} TON.",
    "bet_start": "🎲 Your bet of {amount} TON has been recorded. What are you betting on?",
    "bet_odd": "Odd",
    "bet_even": "Even",
    "bet_timeout": "⏰ Betting time has expired!",
    "bet_dice_rolling": "🎲 Rolling the dice...",
    "roll_dice_instruction": "🎲 Please roll 3 dice using the Telegram dice button.",
    "more_dice_needed": "🎲 Dice {current} of 3 recorded. You need to roll {remaining} more dice. Please use the dice button.",
    "dice_timeout_refund": "⏰ Time to roll the dice has expired! Your bet amount has been refunded.",
    "dice_timeout_no_refund": "⏰ Time to roll the dice has expired! You didn't roll any dice, so your bet amount is lost.",
    "bet_result": "🎲 Dice results: {dice1}, {dice2}, {dice3}\nTotal: {total} ({result})",
    "bet_win": "🎉 Congratulations! You won! {amount} TON has been added to your balance.",
    "bet_lose": "😔 Unfortunately, you lost! {amount} TON has been deducted from your balance.",
    "deposit_info": """
💳 To fund your account, send exactly {amount} TON to the address below:

{address}

The system will automatically verify your transaction and update your account balance.

Please make sure to send the exact amount so the system can identify your transaction.
""",
    "withdraw_success": "✅ Withdrawal of {amount} TON to address {address} was successful.",
    "withdraw_error": "❌ Error in withdrawal. Please try again.",
    "admin_add_success": "✅ {amount} TON has been added to user {user_id}'s balance.",
    "admin_add_error": "❌ Error adding balance. Correct format: /admin_add <user_id> <amount>",
    "not_admin": "❌ This command is only available to the admin.",
    "unknown_command": "❓ Unknown command. Use /help to see the guide.",
    "language_changed": "✅ Language changed to English.",
    "select_language": "🌐 Please select your preferred language:",
    "admin_help": """
⚠️ Admin Commands (admin only):

1️⃣ Add balance with command:
/admin_add <user_id> <amount>

2️⃣ Add balance by replying to a user's message:
Simply reply to the user's message and write +amount. Example: +5

3️⃣ Deduct balance by replying to a user's message:
Simply reply to the user's message and write -amount. Example: -6

4️⃣ Withdrawal requests:
User withdrawal requests will be sent to you and you must process them manually.
"""
}

# Russian messages
MESSAGES_RU = {
    "welcome": """
🎲 Добро пожаловать в TON Betting Bot! 🎲

В этом боте вы можете делать ставки на то, будет ли сумма трех костей четной или нечетной.

Для начала используйте следующие команды:
/balance - Проверить баланс
/deposit <сумма> - Пополнить счет
/withdraw <адрес> <сумма> - Запросить вывод
/risk - Просмотр анализа рисков и истории ставок
/help - Полное руководство по боту
/language - Изменить язык

Или сделайте ставку, используя следующий формат:
#bet odd 0.5
#bet even 0.5

Максимальная ставка: 10 TON
Комиссия за вывод: 5% от запрашиваемой суммы
""",
    
    "help": """
🔹 Руководство по TON Betting Bot 🔹

⚪️ Основные команды:
/balance - Проверить текущий баланс
/deposit <сумма> - Депозит на кошелек бота
/withdraw <адрес> <сумма> - Запросить вывод на ваш кошелек
/language - Изменить язык

⚪️ Метод ставки:
Отправьте сообщение в таком формате:
#bet odd 0.5
#bet even 0.5

⚪️ Правила ставок:
- Вы можете делать ставки на то, будет ли сумма трех костей четной или нечетной
- После отправки ставки вам нужно бросить 3 кости
- Победитель получает сумму ставки, умноженную на 2
- Проигрыш ставки означает потерю суммы ставки

⚪️ Важные примечания:
- Минимальная сумма ставки - 0.1 TON
- Максимальная сумма ставки - 10 TON
- Всегда проверяйте достаточность баланса
- Платежи и выводы обрабатываются в сети TON
- Комиссия за вывод составляет 5% от запрашиваемой суммы
- При выводе с вашего счета вычитается только запрашиваемая сумма плюс комиссия
- Адрес TON кошелька для депозитов: UQD4pyJuRZxozkjl1PFcTE4uBqIRyVdApRD-kM2lzcfD1vts
""",
    
    "balance": "💰 Ваш текущий баланс: {balance} TON",
    "insufficient_balance": "❌ Недостаточный баланс. Ваш текущий баланс {balance} TON.",
    "invalid_bet_amount": "❌ Недействительная сумма ставки. Сумма должна быть не менее {min_bet} TON.",
    "bet_start": "🎲 Ваша ставка в размере {amount} TON зарегистрирована. На что вы ставите?",
    "bet_odd": "Нечетное",
    "bet_even": "Четное",
    "bet_timeout": "⏰ Время ставки истекло!",
    "bet_dice_rolling": "🎲 Бросаем кости...",
    "roll_dice_instruction": "🎲 Пожалуйста, бросьте 3 кости, используя кнопку костей Telegram.",
    "more_dice_needed": "🎲 Записана кость {current} из 3. Вам нужно бросить еще {remaining} костей. Пожалуйста, используйте кнопку костей.",
    "dice_timeout_refund": "⏰ Время для броска костей истекло! Сумма вашей ставки возвращена.",
    "dice_timeout_no_refund": "⏰ Время для броска костей истекло! Вы не бросили ни одной кости, поэтому сумма ставки потеряна.",
    "bet_result": "🎲 Результаты костей: {dice1}, {dice2}, {dice3}\nСумма: {total} ({result})",
    "bet_win": "🎉 Поздравляем! Вы выиграли! {amount} TON добавлен к вашему балансу.",
    "bet_lose": "😔 К сожалению, вы проиграли! {amount} TON вычтен из вашего баланса.",
    "deposit_info": """
💳 Для пополнения счета отправьте ровно {amount} TON на адрес ниже:

{address}

Система автоматически проверит вашу транзакцию и обновит баланс вашего счета.

Пожалуйста, обязательно отправьте точную сумму, чтобы система могла идентифицировать вашу транзакцию.
""",
    "withdraw_success": "✅ Вывод {amount} TON на адрес {address} выполнен успешно.",
    "withdraw_error": "❌ Ошибка при выводе. Пожалуйста, попробуйте еще раз.",
    "admin_add_success": "✅ {amount} TON добавлен к балансу пользователя {user_id}.",
    "admin_add_error": "❌ Ошибка при добавлении баланса. Правильный формат: /admin_add <user_id> <amount>",
    "not_admin": "❌ Эта команда доступна только администратору.",
    "unknown_command": "❓ Неизвестная команда. Используйте /help для просмотра руководства.",
    "language_changed": "✅ Язык изменен на русский.",
    "select_language": "🌐 Пожалуйста, выберите предпочитаемый язык:",
    "admin_help": """
⚠️ Команды администратора (только для администратора):

1️⃣ Добавить баланс командой:
/admin_add <user_id> <сумма>

2️⃣ Добавить баланс, ответив на сообщение пользователя:
Просто ответьте на сообщение пользователя и напишите +сумма. Пример: +5

3️⃣ Вычесть баланс, ответив на сообщение пользователя:
Просто ответьте на сообщение пользователя и напишите -сумма. Пример: -6

4️⃣ Запросы на вывод:
Запросы пользователей на вывод будут отправлены вам, и вы должны обработать их вручную.
"""
}

# Persian messages (rename the original to match the naming pattern)
MESSAGES_FA = MESSAGES

# Function to get messages based on language
def get_messages(language):
    if language == "en":
        return MESSAGES_EN
    elif language == "ru":
        return MESSAGES_RU
    else:  # Default to Persian
        return MESSAGES_FA
