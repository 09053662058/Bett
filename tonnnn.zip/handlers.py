import re
import time
import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from config import MESSAGES, ADMIN_ID, ROLL_TIMEOUT, MIN_BET, MAX_BET, WITHDRAWAL_FEE_PERCENT, LANGUAGES, RISK_ANALYSIS_ENABLED
from utils import (
    get_user_balance, 
    update_balance, 
    validate_bet_amount, 
    roll_dice, 
    is_admin,
    calculate_odds_and_risk,
    get_bet_history,
    update_bet_history,
    get_user_language,
    set_user_language,
    get_message
)

logger = logging.getLogger(__name__)

# Command handlers
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send welcome message when the command /start is issued."""
    user_id = update.effective_user.id
    await update.message.reply_text(get_message("welcome", user_id))

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send help message when the command /help is issued."""
    user_id = update.effective_user.id
    await update.message.reply_text(get_message("help", user_id))

async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user balance"""
    user_id = update.effective_user.id
    balance = get_user_balance(user_id)
    await update.message.reply_text(get_message("balance", user_id, balance=balance))

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks for bets"""
    query = update.callback_query
    await query.answer()
    
    # Extract bet type and amount from callback data
    match = re.match(r'bet_(odd|even)_([\d.]+)', query.data)
    if not match:
        return
    
    bet_type = match.group(1)  # 'odd' or 'even'
    amount = float(match.group(2))
    
    user_id = update.effective_user.id
    
    # Check user balance again (in case it changed)
    current_balance = get_user_balance(user_id)
    if current_balance < amount:
        await query.edit_message_text(MESSAGES["insufficient_balance"].format(balance=current_balance))
        return
    
    # Update message to show instruction for throwing dice
    await query.edit_message_text(MESSAGES["roll_dice_instruction"])
    
    # Deduct bet amount
    update_balance(user_id, -amount)
    
    # Store bet information in context.user_data
    if 'bets' not in context.user_data:
        context.user_data['bets'] = {}
        
    # Generate a unique bet ID
    bet_id = f"{user_id}_{int(time.time())}"
    
    # Store bet information
    context.user_data['bets'][bet_id] = {
        'user_id': user_id,
        'amount': amount,
        'bet_type': bet_type,  # "odd" or "even"
        'dice_thrown': 0,
        'dice_results': [],
        'chat_id': query.message.chat_id,
        'message_id': query.message.message_id
    }
    
    # Set timeout for dice rolling (1 minute)
    context.job_queue.run_once(
        dice_timeout_callback,
        60,  # 1 minute timeout
        data={"bet_id": bet_id},
        name=f"dice_timeout_{bet_id}"
    )
    
    # Remove any pending timeout jobs
    for job in context.job_queue.get_jobs_by_name(f"bet_timeout_{user_id}"):
        job.schedule_removal()

async def deposit_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit command - show deposit address and setup deposit verification"""
    from config import TON_WALLET_ADDRESS, DEPOSIT_CHECK_TIMEOUT
    from utils import verify_ton_deposit
    import asyncio
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    # Ask for amount
    if len(context.args) < 1:
        await update.message.reply_text(
            "لطفاً مبلغ واریز را مشخص کنید:\n/deposit <مبلغ>"
        )
        return
    
    try:
        amount = float(context.args[0])
        if amount <= 0:
            await update.message.reply_text("مبلغ باید بزرگتر از صفر باشد.")
            return
    except ValueError:
        await update.message.reply_text("مبلغ نامعتبر است.")
        return
    
    # Show deposit address and instructions
    await update.message.reply_text(
        MESSAGES["deposit_info"].format(address=TON_WALLET_ADDRESS, amount=amount)
    )
    
    # Tell user we're checking for their deposit
    await update.message.reply_text(
        f"🔍 در حال بررسی واریز {amount} TON...\n\n" \
        f"پس از تأیید تراکنش (حداکثر {int(DEPOSIT_CHECK_TIMEOUT/60)} دقیقه)، موجودی شما به روز می‌شود."
    )
    
    # Start a background task to verify the deposit
    # In a real implementation, you would monitor the blockchain for this transaction
    def check_deposit():
        from utils import verify_ton_deposit
        verify_ton_deposit(TON_WALLET_ADDRESS, amount, user_id, context.bot, chat_id)
    
    # Run the verification in a separate thread to avoid blocking
    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, check_deposit)

async def withdraw_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle withdraw command with fee calculation and security verification"""
    from utils import calculate_withdrawal_fee, reset_user_balance
    
    if len(context.args) < 2:
        await update.message.reply_text("استفاده صحیح: /withdraw <آدرس> <مبلغ>")
        return
    
    address = context.args[0]
    
    try:
        amount = float(context.args[1])
    except ValueError:
        await update.message.reply_text("مبلغ نامعتبر است.")
        return
    
    user_id = update.effective_user.id
    username = update.effective_user.username or "کاربر بدون نام کاربری"
    balance = get_user_balance(user_id)
    
    if amount <= 0:
        await update.message.reply_text("مبلغ باید بزرگتر از صفر باشد.")
        return
    
    # Calculate withdrawal fee
    fee = calculate_withdrawal_fee(amount)
    total_amount = amount + fee
    
    if balance < total_amount:
        await update.message.reply_text(
            f"موجودی کافی نیست. مبلغ درخواستی: {amount} TON + کارمزد {fee} TON = {total_amount} TON\n" \
            f"موجودی فعلی: {balance} TON"
        )
        return
    
    # Let the user know the request is being processed, including fee information
    await update.message.reply_text(
        f"درخواست برداشت شما در حال بررسی است. لطفاً منتظر بمانید.\n\n" \
        f"مبلغ: {amount} TON\n" \
        f"کارمزد: {fee} TON ({WITHDRAWAL_FEE_PERCENT}%)\n" \
        f"مجموع: {total_amount} TON\n\n" \
        f"درحال برسی..."
    )
    
    # Deduct the withdrawal amount (including fee) from user's balance
    update_balance(user_id, -total_amount)
    
    # Notify admin about withdrawal request
    admin_message = f"🔔 درخواست برداشت جدید:\n\n" \
                    f"👤 کاربر: {username} (ID: {user_id})\n" \
                    f"💰 مبلغ خالص: {amount} TON\n" \
                    f"🔸 کارمزد: {fee} TON ({WITHDRAWAL_FEE_PERCENT}%)\n" \
                    f"💳 مجموع کسر شده: {total_amount} TON\n" \
                    f"📝 آدرس: {address}\n\n" \
                    f"برای تأیید برداشت، لطفاً مبلغ {amount} TON را به آدرس فوق ارسال کنید."
    
    # Notify user that the withdrawal request is now being processed by admin
    new_balance = get_user_balance(user_id)
    await update.message.reply_text(
        f"درخواست برداشت شما به ادمین ارسال شد.\nموجودی جدید شما: {new_balance} TON"
    )
    
    try:
        # Send notification to admin
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=admin_message
        )
    except Exception as e:
        logger.error(f"Error sending admin notification: {e}")

async def admin_help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin help message"""
    user_id = update.effective_user.id
    
    # Check if user is admin
    if not is_admin(user_id, ADMIN_ID):
        await update.message.reply_text(MESSAGES["not_admin"])
        return
    
    # Send admin help message
    await update.message.reply_text(MESSAGES["admin_help"])

async def admin_add_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin command to add balance to a user"""
    user_id = update.effective_user.id
    
    # Check if user is admin
    if not is_admin(user_id, ADMIN_ID):
        await update.message.reply_text(MESSAGES["not_admin"])
        return
    
    # Check arguments
    if len(context.args) < 2:
        await update.message.reply_text("استفاده صحیح: /admin_add <user_id> <amount>")
        return
    
    try:
        target_user_id = int(context.args[0])
        amount = float(context.args[1])
        
        if amount <= 0:
            await update.message.reply_text("مبلغ باید مثبت باشد.")
            return
        
        # Add balance to user
        new_balance = update_balance(target_user_id, amount)
        
        await update.message.reply_text(
            MESSAGES["admin_add_success"].format(
                amount=amount,
                user_id=target_user_id
            ) + f"\nموجودی جدید: {new_balance} TON"
        )
    except ValueError:
        await update.message.reply_text(MESSAGES["admin_add_error"])

async def unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle unknown commands"""
    await update.message.reply_text(MESSAGES["unknown_command"])

async def process_dice_throw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process dice throws from users"""
    # Check if this is a dice message
    if not update.message or not update.message.dice:
        return
        
    user_id = update.effective_user.id
    dice_value = update.message.dice.value
    
    # Check if user has active bets
    if 'bets' not in context.user_data:
        return
        
    # Find active bet for this user
    active_bet = None
    bet_id = None
    
    for bid, bet_info in context.user_data['bets'].items():
        if bet_info['user_id'] == user_id and bet_info['dice_thrown'] < 3:
            active_bet = bet_info
            bet_id = bid
            break
            
    if not active_bet:
        return
        
    # Record this dice throw
    active_bet['dice_results'].append(dice_value)
    active_bet['dice_thrown'] += 1
    
    # If this is the third dice, process results
    if active_bet['dice_thrown'] == 3:
        # Calculate total and determine odd/even
        total = sum(active_bet['dice_results'])
        is_even = total % 2 == 0
        result_text = "زوج" if is_even else "فرد"
        
        # Determine win/lose
        bet_type = active_bet['bet_type']
        won = (bet_type == "even" and is_even) or (bet_type == "odd" and not is_even)
        
        # Update bet history
        update_bet_history(user_id, bet_type, won)
        
        # Update user balance
        if won:
            # User wins
            update_balance(user_id, active_bet['amount'] * 2)  # Return bet + winnings
            result_message = MESSAGES["bet_win"].format(amount=active_bet['amount'])
        else:
            # User already lost bet amount
            result_message = MESSAGES["bet_lose"].format(amount=active_bet['amount'])
        
        # Get updated bet history stats
        bet_history = get_bet_history(user_id)
        win_key = f"{bet_type}_wins"
        loss_key = f"{bet_type}_losses"
        wins = bet_history.get(win_key, 0)
        losses = bet_history.get(loss_key, 0)
        total_bets = wins + losses
        win_rate = round((wins / total_bets) * 100, 2) if total_bets > 0 else 0
        
        # Add bet history stats to the result message
        stats_message = f"\n\n📊 آمار شما:\n" \
                      f"تعداد کل شرط‌های {result_text}: {total_bets}\n" \
                      f"تعداد برد: {wins} ({win_rate}%)\n" \
                      f"تعداد باخت: {losses} ({100-win_rate if total_bets > 0 else 0}%)"
        
        # Send result message
        await context.bot.send_message(
            chat_id=active_bet['chat_id'],
            text=MESSAGES["bet_result"].format(
                dice1=active_bet['dice_results'][0],
                dice2=active_bet['dice_results'][1],
                dice3=active_bet['dice_results'][2],
                total=total,
                result=result_text
            ) + "\n\n" + result_message + stats_message
        )
        
        # Remove bet from active bets
        del context.user_data['bets'][bet_id]
        
        # Cancel any timeout jobs
        for job in context.job_queue.get_jobs_by_name(f"dice_timeout_{bet_id}"):
            job.schedule_removal()
    else:
        # Record the dice and wait for more silently
        pass

async def dice_timeout_callback(context: ContextTypes.DEFAULT_TYPE):
    """Handle timeout for dice rolling"""
    bet_id = context.job.data["bet_id"]
    
    # Check if bet still exists
    if 'bets' in context.user_data and bet_id in context.user_data['bets']:
        bet_info = context.user_data['bets'][bet_id]
        
        # Cancel the bet and refund if they've thrown at least one dice
        if bet_info['dice_thrown'] > 0:
            update_balance(bet_info['user_id'], bet_info['amount'])  # Refund
            
            await context.bot.send_message(
                chat_id=bet_info['chat_id'],
                text=MESSAGES["dice_timeout_refund"]
            )
        else:
            await context.bot.send_message(
                chat_id=bet_info['chat_id'],
                text=MESSAGES["dice_timeout_no_refund"]
            )
            
        # Remove the bet
        del context.user_data['bets'][bet_id]

async def language_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Allow user to select their preferred language"""
    user_id = update.effective_user.id
    
    # Create keyboard with language options
    keyboard = [
        [KeyboardButton("🇮🇷 فارسی"), KeyboardButton("🇬🇧 English"), KeyboardButton("🇷🇺 Русский")]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    
    # Send message with language options
    await update.message.reply_text(
        get_message("select_language", user_id),
        reply_markup=reply_markup
    )

async def risk_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show risk analysis and betting history for user"""
    user_id = update.effective_user.id
    balance = get_user_balance(user_id)
    
    # Get bet history
    bet_history = get_bet_history(user_id)
    odd_wins = bet_history.get('odd_wins', 0)
    odd_losses = bet_history.get('odd_losses', 0)
    even_wins = bet_history.get('even_wins', 0)
    even_losses = bet_history.get('even_losses', 0)
    
    total_odd_bets = odd_wins + odd_losses
    total_even_bets = even_wins + even_losses
    total_bets = total_odd_bets + total_even_bets
    
    odd_win_rate = round((odd_wins / total_odd_bets) * 100, 2) if total_odd_bets > 0 else 0
    even_win_rate = round((even_wins / total_even_bets) * 100, 2) if total_even_bets > 0 else 0
    overall_win_rate = round(((odd_wins + even_wins) / total_bets) * 100, 2) if total_bets > 0 else 0
    
    # Create risk analysis message
    message = f"📊 آنالیز ریسک و تاریخچه شرط‌بندی شما:\n\n" \
              f"💰 موجودی فعلی: {balance} TON\n\n" \
              f"📈 آمار کلی:\n" \
              f"تعداد کل شرط‌ها: {total_bets}\n" \
              f"درصد برد کلی: {overall_win_rate}%\n\n" \
              f"🎯 آمار شرط روی فرد:\n" \
              f"تعداد: {total_odd_bets}\n" \
              f"برد: {odd_wins} ({odd_win_rate}%)\n" \
              f"باخت: {odd_losses} ({100-odd_win_rate if total_odd_bets > 0 else 0}%)\n\n" \
              f"🎯 آمار شرط روی زوج:\n" \
              f"تعداد: {total_even_bets}\n" \
              f"برد: {even_wins} ({even_win_rate}%)\n" \
              f"باخت: {even_losses} ({100-even_win_rate if total_even_bets > 0 else 0}%)\n\n" \
              f"📋 پیشنهاد شرط جدید:\n"
    
    # Add betting suggestion based on history
    if total_bets > 5:  # Only give suggestions if they have some history
        if odd_win_rate > even_win_rate:
            message += f"بر اساس تاریخچه شما، شرط روی فرد با نرخ برد {odd_win_rate}% شانس بهتری دارد.\n"
        elif even_win_rate > odd_win_rate:
            message += f"بر اساس تاریخچه شما، شرط روی زوج با نرخ برد {even_win_rate}% شانس بهتری دارد.\n"
        else:
            message += "بر اساس تاریخچه شما، شانس برد در هر دو گزینه فرد و زوج یکسان است.\n"
        
        # Suggest bet amount
        if balance > 0:
            suggested_amount = min(round(balance * 0.1, 2), MAX_BET)
            message += f"مبلغ پیشنهادی برای شرط جدید: {suggested_amount} TON (10% از موجودی شما)\n"
    else:
        message += "برای دریافت پیشنهاد شرط، حداقل 5 شرط انجام دهید.\n"
    
    await update.message.reply_text(message)

async def text_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages that may contain bet patterns, language selection or admin commands"""
    if update.message is None:
        return
        
    text = update.message.text
    user_id = update.effective_user.id
    
    # Check for language selection messages
    if text == "🇮🇷 فارسی":
        set_user_language(user_id, "fa")
        await update.message.reply_text("✅ زبان شما به فارسی تغییر کرد.")
        return
    elif text == "🇬🇧 English":
        set_user_language(user_id, "en")
        await update.message.reply_text(get_message("language_changed", user_id))
        return
    elif text == "🇷🇺 Русский":
        set_user_language(user_id, "ru")
        await update.message.reply_text(get_message("language_changed", user_id))
        return
    
    # Check if admin is replying to a user with +amount or -amount format
    if update.message.reply_to_message and is_admin(user_id, ADMIN_ID):
        if (text.startswith('+') or text.startswith('-')) and text[1:].replace('.', '', 1).isdigit():
            # Get the replied user
            replied_user_id = update.message.reply_to_message.from_user.id
            
            # Determine if adding or subtracting
            if text.startswith('+'):
                amount = float(text[1:])
                action_text = "اضافه شد"
            else:
                amount = -float(text[1:])  # Negative amount for deduction
                action_text = "کم شد"
            
            # Update balance
            new_balance = update_balance(replied_user_id, amount)
            
            # Send confirmation
            absolute_amount = abs(amount)
            await update.message.reply_text(
                f"✅ {absolute_amount} TON از موجودی کاربر {replied_user_id} {action_text}.\n"
                f"موجودی جدید: {new_balance} TON"
            )
            return
    
    # Check for betting pattern in different languages
    # Persian: #شرط فرد 0.5 or #شرط زوج 0.5
    # English: #bet odd 0.5 or #bet even 0.5
    # Russian: #ставка нечет 0.5 or #ставка чет 0.5
    persian_bet_match = re.match(r'^#شرط (فرد|زوج) ([\d.]+)$', text)
    english_bet_match = re.match(r'^#bet (odd|even) ([\d.]+)$', text)
    russian_bet_match = re.match(r'^#ставка (нечет|чет) ([\d.]+)$', text)
    
    bet_match = persian_bet_match or english_bet_match or russian_bet_match
    if bet_match:
        bet_type = bet_match.group(1)  # could be 'فرد', 'زوج', 'odd', 'even', 'нечет', 'чет'
        amount_str = bet_match.group(2)
        
        user_id = update.effective_user.id
        user_lang = get_user_language(user_id)
        
        # Validate bet amount
        is_valid, result = validate_bet_amount(amount_str, user_id)
        
        if not is_valid:
            await update.message.reply_text(result)
            return
        
        amount = float(result)
        
        # Convert the bet type to standard format (odd/even)
        if bet_type in ["فرد", "odd", "нечет"]:
            bet_type_str = "odd"
            display_bet_type = get_message("bet_odd", user_id)
        else:  # bet_type in ["زوج", "even", "чет"]
            bet_type_str = "even"
            display_bet_type = get_message("bet_even", user_id)
        # Removed risk analysis
        
        # Show bet confirmation message in user's language
        if user_lang == "en":
            risk_message = f"🎲 Your bet has been placed:\n\n" \
                          f"💰 Bet amount: {amount} TON\n" \
                          f"🎯 Bet type: {display_bet_type}\n\n" \
                          f"🎲 Please roll 3 dice using the Telegram dice button."
        elif user_lang == "ru":
            risk_message = f"🎲 Ваша ставка размещена:\n\n" \
                          f"💰 Сумма ставки: {amount} TON\n" \
                          f"🎯 Тип ставки: {display_bet_type}\n\n" \
                          f"🎲 Пожалуйста, бросьте 3 кости, используя кнопку кости Telegram."
        else:  # Persian (default)
            risk_message = f"🎲 شرط شما ثبت شد:\n\n" \
                          f"💰 مبلغ شرط: {amount} TON\n" \
                          f"🎯 نوع شرط: {display_bet_type}\n\n" \
                          f"🎲 لطفاً با استفاده از دکمه تاس تلگرام، ۳ تاس بیندازید."
        
        await update.message.reply_text(risk_message)
        
        # Deduct bet amount
        update_balance(user_id, -amount)
        
        # Store bet information in context.user_data
        if 'bets' not in context.user_data:
            context.user_data['bets'] = {}
            
        # Generate a unique bet ID
        bet_id = f"{user_id}_{int(time.time())}"
        
        # Store bet information
        context.user_data['bets'][bet_id] = {
            'user_id': user_id,
            'amount': amount,
            'bet_type': bet_type_str,  # "odd" or "even"
            'dice_thrown': 0,
            'dice_results': [],
            'chat_id': update.message.chat_id,
            'message_id': update.message.message_id
        }
        
        # Set timeout for dice rolling (1 minute)
        context.job_queue.run_once(
            dice_timeout_callback,
            60,  # 1 minute timeout
            data={"bet_id": bet_id},
            name=f"dice_timeout_{bet_id}"
        )
