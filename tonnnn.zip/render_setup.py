# This file is for setting up the project on Render.com
# Run this script once to set up your environment

import os
import json
from pathlib import Path

# Create requirements.txt if it doesn't exist
def create_requirements():
    requirements = [
        "python-telegram-bot>=20.0",
        "flask",
        "gunicorn",
        "requests",
        "nest-asyncio"
    ]
    
    with open("requirements.txt", "w") as f:
        f.write("\n".join(requirements))
    print("✅ Created requirements.txt")

# Create a Procfile for Render/Heroku
def create_procfile():
    with open("Procfile", "w") as f:
        f.write("worker: python main.py")
    print("✅ Created Procfile")

# Create a start.sh script for Railway/other platforms
def create_start_script():
    with open("start.sh", "w") as f:
        f.write("#!/bin/bash\npython main.py")
    
    # Make it executable
    os.chmod("start.sh", 0o755)
    print("✅ Created start.sh")

# Create README file with deployment instructions
def create_readme():
    readme = """
# TON Betting Bot

A Telegram bot for betting on dice roll outcomes using TON cryptocurrency.

## Features

- Place bets on odd or even dice roll outcomes
- Multilingual support (Persian, English, Russian)
- Automatic wallet verification
- Admin notifications for withdrawal requests

## Deployment Instructions

### Prerequisites

- Python 3.7 or higher
- A Telegram bot token (from @BotFather)
- Admin Telegram user ID

### Setup on Render.com (Free Tier)

1. Create a new Web Service on Render
2. Connect your GitHub repository
3. Select "Python 3" as the environment
4. Set the Build Command: `pip install -r requirements.txt`
5. Set the Start Command: `python main.py`
6. Add Environment Variables:
   - `TELEGRAM_TOKEN`: Your Telegram bot token
   - `ADMIN_ID`: Your Telegram user ID (for admin functions)

### Setup on Railway.app (Free Credits)

1. Create a new project on Railway
2. Connect your GitHub repository
3. Add Environment Variables:
   - `TELEGRAM_TOKEN`: Your Telegram bot token
   - `ADMIN_ID`: Your Telegram user ID (for admin functions)
4. Railway will automatically detect the Procfile and run your bot

### Setup on PythonAnywhere (Free Tier)

1. Create a new account on PythonAnywhere
2. Upload your files or clone your repository
3. Set up a new task (Console → Tasks)
4. Command: `python /home/yourusername/main.py`
5. Set it to run daily and manually start it for the first time

## Configuration

All configuration settings are in `config.py`. You can adjust:

- Minimum and maximum bet amounts
- Withdrawal fee percentage
- Default language
- TON wallet address for deposits
"""
    
    with open("README.md", "w") as f:
        f.write(readme)
    print("✅ Created README.md with deployment instructions")

# Create data directory if it doesn't exist
def ensure_data_directory():
    data_dir = Path("data")
    data_dir.mkdir(exist_ok=True)
    
    # Create an empty users.json file if it doesn't exist
    users_file = data_dir / "users.json"
    if not users_file.exists():
        with open(users_file, "w") as f:
            json.dump({}, f)
        print("✅ Created empty users.json file")

# Main setup function
def setup():
    print("🚀 Setting up project for deployment...")
    create_requirements()
    create_procfile()
    create_start_script()
    create_readme()
    ensure_data_directory()
    print("\n✨ Setup complete! Your project is ready for deployment.")
    print("\n📝 Make sure to set the following environment variables on your hosting platform:")
    print("   - TELEGRAM_TOKEN: Your Telegram bot token")
    print("   - ADMIN_ID: Your Telegram user ID (for admin functions)")

if __name__ == "__main__":
    setup()
