#!/usr/bin/env python
import logging
from bot import setup_bot
from flask import Flask

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

logger = logging.getLogger(__name__)

# Create Flask app for Gunicorn
app = Flask(__name__)

@app.route('/')
def home():
    return "Telegram Bot Server is running!"

if __name__ == '__main__':
    # Import keep_alive function for continuous operation
    from keep_alive import keep_alive
    
    # Start the keep-alive Flask server
    keep_alive()
    
    # Initialize and run the bot
    setup_bot()
