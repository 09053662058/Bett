from flask import Flask
from threading import Thread
import logging

# Disable Flask logging except for errors
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

app = Flask('')

@app.route('/')
def home():
    return "TON Betting Bot is alive!"

def run():
    # Run the Flask server in a separate port to not conflict with gunicorn
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    # Start Flask server in a separate thread to keep the repl alive
    server_thread = Thread(target=run)
    server_thread.daemon = True  # Set as daemon so it terminates when main thread exits
    server_thread.start()
    print("📢 Keep alive server started on port 8080")
