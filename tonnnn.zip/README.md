
# TON Betting Bot

A Telegram bot for betting on dice roll outcomes using TON cryptocurrency.

## Features

- Place bets on odd or even dice roll outcomes
- Multilingual support (Persian, English, Russian)
- Automatic wallet verification
- Admin notifications for withdrawal requests

## Deployment Instructions

### Prerequisites

- Python 3.7 or higher
- A Telegram bot token (from @BotFather)
- Admin Telegram user ID

### Setup on Render.com (Free Tier)

1. Create a new Web Service on Render
2. Connect your GitHub repository
3. Select "Python 3" as the environment
4. Set the Build Command: `pip install -r requirements.txt`
5. Set the Start Command: `python main.py`
6. Add Environment Variables:
   - `TELEGRAM_TOKEN`: Your Telegram bot token
   - `ADMIN_ID`: Your Telegram user ID (for admin functions)

### Setup on Railway.app (Free Credits)

1. Create a new project on Railway
2. Connect your GitHub repository
3. Add Environment Variables:
   - `TELEGRAM_TOKEN`: Your Telegram bot token
   - `ADMIN_ID`: Your Telegram user ID (for admin functions)
4. Railway will automatically detect the Procfile and run your bot

### Setup on PythonAnywhere (Free Tier)

1. Create a new account on PythonAnywhere
2. Upload your files or clone your repository
3. Set up a new task (Console → Tasks)
4. Command: `python /home/yourusername/main.py`
5. Set it to run daily and manually start it for the first time

## Configuration

All configuration settings are in `config.py`. You can adjust:

- Minimum and maximum bet amounts
- Withdrawal fee percentage
- Default language
- TON wallet address for deposits
