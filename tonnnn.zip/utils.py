import json
import os
import random
import logging
import requests
import time
import threading
from config import USER_DATA_FILE, MIN_BET, MAX_BET, WITHDRAWAL_FEE_PERCENT, TON_WALLET_ADDRESS, DEFAULT_LANGUAGE, LANGUAGES
from config import MESSAGES_FA, MESSAGES_EN, MESSAGES_RU

logger = logging.getLogger(__name__)

def load_user_data():
    """Load user data from JSON file"""
    if os.path.exists(USER_DATA_FILE):
        try:
            with open(USER_DATA_FILE, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error("Error decoding user data file, creating new one")
            return {}
    return {}

def save_user_data(data):
    """Save user data to JSON file"""
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def get_user_balance(user_id):
    """Get balance for a specific user"""
    users = load_user_data()
    user_id = str(user_id)  # Convert to string to use as dict key
    
    if user_id in users:
        return users[user_id].get('balance', 0.0)
    else:
        # Initialize new user
        users[user_id] = {
            'balance': 0.0,
            'wallet_address': None,
            'language': DEFAULT_LANGUAGE,
            'bet_history': {
                'odd_wins': 0,
                'odd_losses': 0,
                'even_wins': 0,
                'even_losses': 0
            }
        }
        save_user_data(users)
        return 0.0

def update_balance(user_id, amount):
    """Update user balance by adding/subtracting amount"""
    users = load_user_data()
    user_id = str(user_id)
    
    if user_id not in users:
        users[user_id] = {
            'balance': 0.0,
            'wallet_address': None,
            'language': DEFAULT_LANGUAGE,
            'bet_history': {
                'odd_wins': 0,
                'odd_losses': 0,
                'even_wins': 0,
                'even_losses': 0
            }
        }
    
    users[user_id]['balance'] = round(users[user_id].get('balance', 0.0) + amount, 8)
    save_user_data(users)
    return users[user_id]['balance']

def set_wallet_address(user_id, address):
    """Set wallet address for a user"""
    users = load_user_data()
    user_id = str(user_id)
    
    if user_id not in users:
        users[user_id] = {
            'balance': 0.0,
            'wallet_address': None,
            'language': DEFAULT_LANGUAGE,
            'bet_history': {
                'odd_wins': 0,
                'odd_losses': 0,
                'even_wins': 0,
                'even_losses': 0
            }
        }
    
    users[user_id]['wallet_address'] = address
    save_user_data(users)

def get_wallet_address(user_id):
    """Get wallet address for a user"""
    users = load_user_data()
    user_id = str(user_id)
    
    if user_id in users:
        return users[user_id].get('wallet_address')
    return None

def validate_bet_amount(amount, user_id):
    """Validate if a bet amount is valid"""
    try:
        amount = float(amount)
        if amount < MIN_BET:
            return False, f"مبلغ شرط باید حداقل {MIN_BET} TON باشد."
        
        if amount > MAX_BET:
            return False, f"مبلغ شرط نمی‌تواند بیشتر از {MAX_BET} TON باشد."
            
        user_balance = get_user_balance(user_id)
        if amount > user_balance:
            return False, f"موجودی کافی نیست. موجودی فعلی: {user_balance} TON"
            
        return True, amount
    except ValueError:
        return False, "مبلغ وارد شده نامعتبر است."

def roll_dice():
    """Roll three dice and return results"""
    dice1 = random.randint(1, 6)
    dice2 = random.randint(1, 6)
    dice3 = random.randint(1, 6)
    total = dice1 + dice2 + dice3
    is_even = total % 2 == 0
    
    return {
        'dice1': dice1,
        'dice2': dice2,
        'dice3': dice3,
        'total': total,
        'is_even': is_even
    }

def calculate_withdrawal_fee(amount):
    """Calculate fee for withdrawal"""
    fee = round(amount * (WITHDRAWAL_FEE_PERCENT / 100), 8)
    return fee

def calculate_odds_and_risk(bet_type, bet_amount, user_id):
    """Calculate odds and risk for a bet
    
    This function calculates the odds, potential profit, and risk level for a bet.
    - Odds for odd/even are 50/50 in a fair dice roll
    - Risk level is calculated based on bet amount compared to user's total balance
    - Returns probability percentage, potential profit, and risk level (low, medium, high)
    """
    balance = get_user_balance(user_id)
    
    # Calculate probability
    # Since we're using 3 dice with equal probability of odd/even, it's 50%
    probability = 50.0
    
    # Calculate potential profit (if win)
    potential_profit = bet_amount * 2
    profit_percentage = round((bet_amount / potential_profit) * 100, 2)
    
    # Calculate risk level based on percentage of balance
    balance_percentage = round((bet_amount / balance) * 100 if balance > 0 else 100, 2)
    
    if balance_percentage < 20:
        risk_level = "کم"
    elif balance_percentage < 50:
        risk_level = "متوسط"
    else:
        risk_level = "بالا"
    
    # Calculate win/loss history for this bet type
    bet_history = get_bet_history(user_id)
    odd_wins = bet_history.get('odd_wins', 0)
    odd_losses = bet_history.get('odd_losses', 0)
    even_wins = bet_history.get('even_wins', 0)
    even_losses = bet_history.get('even_losses', 0)
    
    if bet_type == "odd":
        total_bets = odd_wins + odd_losses
        win_count = odd_wins
    else:  # even
        total_bets = even_wins + even_losses
        win_count = even_wins
    
    win_percentage = round((win_count / total_bets) * 100, 2) if total_bets > 0 else 0
    
    # Historical performance message
    if total_bets > 0:
        history_message = f"عملکرد شما در {total_bets} شرط قبلی {bet_type}: {win_percentage}% برد"
    else:
        history_message = f"هنوز هیچ شرطی روی {bet_type} نداشته‌اید"
    
    return {
        "probability": probability,
        "potential_profit": potential_profit,
        "risk_level": risk_level,
        "risk_percentage": balance_percentage,
        "history_message": history_message,
        "win_percentage": win_percentage
    }

def verify_ton_deposit(wallet_address, expected_amount, user_id, bot=None, chat_id=None):
    """Verify a TON deposit transaction
    
    This is a simplified version. In a real implementation, you would:
    1. Query TON blockchain API to check for recent transactions to your wallet
    2. Verify the amount and sender
    3. Update user balance if verified
    
    For demonstration purposes, this function simulates verifying a transaction
    """
    try:
        # Simulating checking the blockchain - in a real scenario you would use a TON API
        # This is a placeholder - in production you should implement an actual TON blockchain check
        logger.info(f"Checking for deposit of {expected_amount} TON to {wallet_address} for user {user_id}")
        
        # Sleep to simulate async checking
        time.sleep(3)
        
        # For demonstration, we'll approve all deposit requests automatically
        # In production, implement proper blockchain verification
        update_balance(user_id, expected_amount)
        
        if bot and chat_id:
            threading.Thread(target=send_deposit_confirmation, 
                           args=(bot, chat_id, expected_amount)).start()
        return True
    except Exception as e:
        logger.error(f"Error verifying TON deposit: {e}")
        return False

def send_deposit_confirmation(bot, chat_id, amount):
    """Send message confirming deposit was processed"""
    try:
        bot.send_message(
            chat_id=chat_id,
            text=f"✅ واریز {amount} TON با موفقیت انجام شد و به موجودی شما اضافه شد."
        )
    except Exception as e:
        logger.error(f"Error sending deposit confirmation: {e}")

def reset_user_balance(user_id):
    """Reset user balance to zero (anti-fraud measure after withdrawal)"""
    users = load_user_data()
    user_id = str(user_id)
    
    if user_id in users:
        users[user_id]['balance'] = 0.0
        save_user_data(users)
    
    return 0.0

def get_bet_history(user_id):
    """Get bet history for a user"""
    users = load_user_data()
    user_id = str(user_id)
    
    if user_id in users and 'bet_history' in users[user_id]:
        return users[user_id]['bet_history']
    else:
        # Initialize bet history if not exists
        if user_id not in users:
            users[user_id] = {
                'balance': 0.0,
                'wallet_address': None,
                'bet_history': {
                    'odd_wins': 0,
                    'odd_losses': 0,
                    'even_wins': 0,
                    'even_losses': 0
                }
            }
        elif 'bet_history' not in users[user_id]:
            users[user_id]['bet_history'] = {
                'odd_wins': 0,
                'odd_losses': 0,
                'even_wins': 0,
                'even_losses': 0
            }
        save_user_data(users)
        return users[user_id]['bet_history']

def update_bet_history(user_id, bet_type, won):
    """Update bet history for a user"""
    users = load_user_data()
    user_id = str(user_id)
    
    # Initialize user if not exists
    if user_id not in users:
        users[user_id] = {
            'balance': 0.0,
            'wallet_address': None,
            'bet_history': {
                'odd_wins': 0,
                'odd_losses': 0,
                'even_wins': 0,
                'even_losses': 0
            }
        }
    # Initialize bet history if not exists
    elif 'bet_history' not in users[user_id]:
        users[user_id]['bet_history'] = {
            'odd_wins': 0,
            'odd_losses': 0,
            'even_wins': 0,
            'even_losses': 0
        }
    
    # Update appropriate counter
    if bet_type == "odd":
        if won:
            users[user_id]['bet_history']['odd_wins'] += 1
        else:
            users[user_id]['bet_history']['odd_losses'] += 1
    else:  # even
        if won:
            users[user_id]['bet_history']['even_wins'] += 1
        else:
            users[user_id]['bet_history']['even_losses'] += 1
    
    save_user_data(users)

def get_user_language(user_id):
    """Get preferred language for a user"""
    users = load_user_data()
    user_id = str(user_id)  # Convert to string for JSON key
    
    if user_id in users and 'language' in users[user_id]:
        return users[user_id]['language']
    else:
        # Set default language if not set
        if user_id not in users:
            users[user_id] = {
                'balance': 0.0, 
                'wallet_address': None, 
                'language': DEFAULT_LANGUAGE,
                'bet_history': {
                    'odd_wins': 0,
                    'odd_losses': 0,
                    'even_wins': 0,
                    'even_losses': 0
                }
            }
        elif 'language' not in users[user_id]:
            users[user_id]['language'] = DEFAULT_LANGUAGE
        save_user_data(users)
        return DEFAULT_LANGUAGE

def set_user_language(user_id, language):
    """Set preferred language for a user"""
    user_id = str(user_id)  # Convert to string for JSON key
    
    # Validate language code
    if language not in LANGUAGES:
        return False
        
    users = load_user_data()
    
    # Initialize user if doesn't exist
    if user_id not in users:
        users[user_id] = {
            'balance': 0.0, 
            'wallet_address': None, 
            'language': language,
            'bet_history': {
                'odd_wins': 0,
                'odd_losses': 0,
                'even_wins': 0,
                'even_losses': 0
            }
        }
    else:
        users[user_id]['language'] = language
        
    save_user_data(users)
    return True

def get_message(key, user_id, **kwargs):
    """Get a message in the user's preferred language"""
    lang = get_user_language(user_id)
    
    if lang == "en":
        messages = MESSAGES_EN
    elif lang == "ru":
        messages = MESSAGES_RU
    else:  # Default to Persian
        messages = MESSAGES_FA
        
    # Get the message and format it with kwargs
    if key in messages:
        return messages[key].format(**kwargs) if kwargs else messages[key]
    else:
        # Fallback to Persian if key not found in user's language
        return MESSAGES_FA.get(key, "Message not found").format(**kwargs) if kwargs else MESSAGES_FA.get(key, "Message not found")

def is_admin(user_id, admin_id):
    """Check if user is admin"""
    return int(user_id) == admin_id
